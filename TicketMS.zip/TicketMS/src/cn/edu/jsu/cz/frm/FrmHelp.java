package cn.edu.jsu.cz.frm;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.DropMode;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import java.awt.Toolkit;

/**
 * ϵͳ����������ʾ��Ϣ����
 * @author 86159
 *
 */
public class FrmHelp extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmHelp frame = new FrmHelp();
					frame.setVisible(true); 
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmHelp() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmHelp.class.getResource("/cn/edu/jsu/cz/frm/image/11.png")));
		setTitle("\u5E2E\u52A9");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//
		setBounds(100, 100, 452, 330);
		contentPane = new JPanel();  
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u60A8\u6765\u5230\u5728\u7EBF\u8F66\u7968\u67E5\u8BE2\u9884\u8BA2\u7BA1\u7406\u7CFB\u7EDF\uFF0C\u60A8\u53EA");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 10, 416, 49);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u9700\u6839\u636E\u60A8\u7684\u8EAB\u4EFD\u70B9\u51FB\u5DE6\u4E0A\u89D2\u83DC\u5355\u5BF9\u5E94\u7684\u6309\u94AE,");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(10, 47, 397, 37);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u8FDB\u884C\u767B\u5F55 \uFF08\u6CE8\u518C\uFF09 \u5373\u53EF\u4F7F\u7528 \uFF0C\u6700\u540E\u795D\u60A8");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(10, 80, 397, 32);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u4F7F\u7528\u6109\u5FEB\uFF01\uFF01\uFF01");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(10, 112, 364, 32);
		contentPane.add(lblNewLabel_3);
	}
}
