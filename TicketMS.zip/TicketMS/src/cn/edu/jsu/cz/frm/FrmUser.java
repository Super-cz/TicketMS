package cn.edu.jsu.cz.frm;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cn.edu.jsu.cz.vo.CarManager;

import javax.swing.JMenuBar;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

/**
 * ���߳�Ʊ��ѯԤ������ϵͳ�����棨ϵͳ��ڽ��棩
 * @author 86159
 *
 */
public class FrmUser extends JFrame {
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmUser frame = new FrmUser();
					frame.setLocationRelativeTo(null);//�������
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//�����û��ڴ˴����Ϸ��� "close" ʱĬ��ִ�еĲ���
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmUser() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmUser.class.getResource("/cn/edu/jsu/cz/frm/image/7.png")));
		setTitle("\u5728\u7EBF\u8F66\u7968\u67E5\u8BE2\u9884\u5B9A\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 710, 510); 
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(Color.BLACK);
		setJMenuBar(menuBar);
		
		JButton btnNewButton = new JButton("\u6211\u662F\u65C5\u5BA2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmTra frame = new FrmTra();
				frame.setLocationRelativeTo(null); 
				frame.setVisible(true);
				setVisible(false);
			}
		});
		menuBar.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u6211\u662F\u8F66\u7AD9\u7BA1\u7406\u5458");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmCM frame = new FrmCM(new CarManager());
				frame.setLocationRelativeTo(null); 
				frame.setVisible(true);
				setVisible(false);
			}

		
		});
		menuBar.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u6211\u662F\u7CFB\u7EDF\u7BA1\u7406\u5458");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmSM frame = new FrmSM();
				frame.setLocationRelativeTo(null); 
				frame.setVisible(true);
				setVisible(false);
			}
		});
		menuBar.add(btnNewButton_2);
		
		JButton btnNewButton_4 = new JButton("\u5E2E\u52A9");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmHelp frame = new FrmHelp();
				frame.setLocationRelativeTo(null); 
				frame.setVisible(true);
				//setVisible(false);
			}
		});
		menuBar.add(btnNewButton_4);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_3 = new JButton("\u8FDB\u5165\u4F7F\u7528\u7CFB\u7EDF");//������ʹ��ϵͳ����ť
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmHelp frame = new FrmHelp();
				frame.setLocationRelativeTo(null); 
				frame.setVisible(true);
				//setVisible(false);
			}
		});
		btnNewButton_3.setBounds(222, 194, 146, 50);
		contentPane.add(btnNewButton_3);		
		btnNewButton_3.setContentAreaFilled(false);// ���ð�ť͸��
		btnNewButton_3.setBorder(null);// ȡ���߿�
		btnNewButton_3.setFont(new Font("����", Font.PLAIN, 17));
		contentPane.add(btnNewButton_3, BorderLayout.CENTER); 
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u8FDB\u5165\u5728\u7EBF\u8F66\u7968\u67E5\u8BE2\u9884\u5B9A\u7CFB\u7EDF*\\(^_^)/*");
		//��ӭ��ǩ
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 10, 292, 50);
		contentPane.add(lblNewLabel);
		
		//����ͼƬ
        ImageIcon icon1=new ImageIcon("D:/javademo/TicketMS/image/1.png" );
        //����JLabel ����ͼƬ
        JLabel label1=new JLabel(icon1);
        //����label��λ�á���С��label��СΪͼƬ�Ĵ�С
        label1.setBounds(0,0,icon1.getIconWidth(),icon1.getIconHeight());
        getContentPane().add(label1);
	}
	
}
