package cn.edu.jsu.cz.frm;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cn.edu.jsu.cz.dbc.DatabaseConnectionSql;
import cn.edu.jsu.cz.util.SmDelAndUpdOperation;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * ϵͳ����Ա���ӳ�����Ϣ����
 * @author 86159
 *
 */
public class FrmSmMainAddOperation extends JFrame {

	private static Connection conn=null;
	private static PreparedStatement pstmt=null;
	private static String id;
	private static String startp;
	private static String endp;
	private static String stime;
	private static int Tnum;
	private static int Tprice;
	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;
	private JTextField txt3;
	private JTextField txt4;
	private JTextField txt5;
	private JTextField txt6;
	private JLabel lbl1;
	private JLabel lbl2;
	private JLabel lbl3;
	private JLabel lbl4;
	private JLabel lbl5;
	private JLabel lbl6;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmSmMainAddOperation frame = new FrmSmMainAddOperation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmSmMainAddOperation() {
		setTitle("\u589E\u52A0\u8F66\u6B21\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 542, 504);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8F66\u6B21\u53F7");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(33, 30, 91, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u59CB\u53D1\u5730");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(33, 90, 91, 28);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u76EE\u7684\u5730");
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setBounds(33, 150, 91, 28);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u53D1\u8F66\u65F6\u95F4");
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setBounds(33, 210, 91, 28);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u5269\u4F59\u7968\u6570");
		lblNewLabel_4.setForeground(Color.BLACK);
		lblNewLabel_4.setBounds(33, 270, 91, 28);
		contentPane.add(lblNewLabel_4);	
		
		JLabel lblNewLabel_5 = new JLabel("\u7968\u4EF7");
		lblNewLabel_5.setBounds(33, 336, 58, 15);
		contentPane.add(lblNewLabel_5);
		
		txt1 = new JTextField();
		txt1.setBounds(134, 33, 233, 28);
		contentPane.add(txt1);
		txt1.setColumns(10);		
		
		txt2 = new JTextField();
		txt2.setBounds(134, 93, 233, 28);
		contentPane.add(txt2);
		txt2.setColumns(10);
		
		txt3 = new JTextField();
		txt3.setBounds(134, 153, 233, 28);
		contentPane.add(txt3);
		txt3.setColumns(10);
		
		txt4 = new JTextField();
		txt4.setBounds(134, 213, 233, 28);
		contentPane.add(txt4);
		txt4.setColumns(10);
		
		txt5 = new JTextField();
		txt5.setBounds(134, 271, 233, 28);
		contentPane.add(txt5);
		txt5.setColumns(10);
		
		txt6 = new JTextField();
		txt6.setBounds(134, 330, 235, 28);
		contentPane.add(txt6);
		txt6.setColumns(10);
		this.setLocationRelativeTo(null);
		
		lbl1 = new JLabel("");
		lbl1.setForeground(Color.RED);
		lbl1.setBounds(381, 37, 115, 20);
		contentPane.add(lbl1);
		
		lbl2 = new JLabel("");
		lbl2.setForeground(Color.RED);
		lbl2.setBounds(381, 97, 115, 20);
		contentPane.add(lbl2);
		
		lbl3 = new JLabel("");
		lbl3.setForeground(Color.RED);
		lbl3.setBounds(395, 157, 115, 20);
		contentPane.add(lbl3);
		
		lbl4 = new JLabel("");
		lbl4.setForeground(Color.RED);
		lbl4.setBounds(395, 217, 115, 20);
		contentPane.add(lbl4);
		
		lbl5 = new JLabel("");
		lbl5.setForeground(Color.RED);
		lbl5.setBounds(395, 277, 115, 20);
		contentPane.add(lbl5);
		
		lbl6 = new JLabel("");
		lbl6.setForeground(Color.RED);
		lbl6.setBounds(395, 333, 101, 25);
		contentPane.add(lbl6);
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(check1()) {
						if(check2()) {
							if(check3()) {
								if(check4()) {
									if(check5()) {
									Integer a=Integer.parseInt(txt5.getText());
									Integer b=Integer.parseInt(txt6.getText());
									SmDelAndUpdOperation.add(txt1.getText(),txt2.getText(),txt3.getText(),txt4.getText(),a,b);
					                JOptionPane.showMessageDialog(null, "���ӳɹ�");//Double.parseDouble(txt2.getText())
					                txt1.setText("");
					                txt2.setText("");
					                txt3.setText("");
					                txt4.setText("");
					                txt5.setText("");
					                txt6.setText("");
									}
								}
							}
						}
					}
					
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(174, 387, 129, 44);
		contentPane.add(btnNewButton);
		

		
	}
	public boolean check1() {
		  if(txt1.getText().length()==0) {
		    lbl1.setText("���κŲ���Ϊ��");
		    txt1.requestFocus();
		    return false;
		  }
		  lbl1.setText("");
		  return true;
	}
	
	public boolean check2() {
		  if(txt2.getText().length()==0) {
		    lbl2.setText("ʼ���ز���Ϊ��");
		    txt2.requestFocus();
		    return false;
		  }
		  lbl2.setText("");
		  return true;
	}
	
	public boolean check3() {
		  if(txt3.getText().length()==0) {
		    lbl3.setText("Ŀ�ĵز���Ϊ��");
		    txt3.requestFocus();
		    return false;
		  }
		  lbl3.setText("");
		  return true;
	}
	
	public boolean check4() {
		  if(txt4.getText().length()==0) {
		    lbl4.setText("����ʱ�䲻��Ϊ��");
		    txt4.requestFocus();
		    return false;
		  }
		  lbl4.setText("");
		  return true;
	}
	
	public boolean check5() {
		  if(txt5.getText().length()==0) {
		    lbl5.setText("ʣ��Ʊ������Ϊ��");
		    txt5.requestFocus();
		    return false;
		  }else if(!txt5.getText().matches("\\d+")) {//����ƥ������
			    lbl5.setText("ʣ��Ʊ������������");
			    txt5.requestFocus();
			    txt5.selectAll();//ȫѡ���е�����
			    return false;
		  }
		  lbl5.setText("");
		  return true;
	}
	
	public boolean check6() {
		  if(txt6.getText().length()==0) {
		    lbl6.setText("Ʊ�۲���Ϊ��");
		    txt6.requestFocus();
		    return false;
		  }else if(!txt6.getText().matches("\\d+")) {//����ƥ������
			    lbl6.setText("Ʊ�۱���������");
			    txt6.requestFocus();
			    txt6.selectAll();//ȫѡ���е�����
			    return false;
		  }
		  lbl6.setText("");
		  return true;
	}

}
