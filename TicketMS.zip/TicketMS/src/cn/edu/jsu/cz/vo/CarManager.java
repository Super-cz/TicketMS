package cn.edu.jsu.cz.vo;

import java.io.Serializable;
import javax.swing.ImageIcon;
/**
 * �û����˺ţ�������¼ϵͳ
 * @author 
 *
 */
public class CarManager implements Serializable{
	private String username;//�û���
	private String password;//����
	private String place;//���ڵ�
	public CarManager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CarManager(String username, String password, String place) { 
		super();
		this.username = username;
		this.password = password;
		this.place = place;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getplace() {
		return place;
	}
	public void setplace(String place) {
		this.place = place;
	}
	@Override
	public String toString() {
		return "User [Username=" + username + ", password=" + password +", place=" + place + "]";
	}
	
}
